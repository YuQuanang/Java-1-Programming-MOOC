
import java.util.Scanner;

public class Same {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        // Write your program here. 
        System.out.println("Enter the first string:");
        String pass = String.valueOf(scan.nextLine());

        System.out.println("Enter the second string:");
        String pass1 = String.valueOf(scan.nextLine());

        if(pass.equals(pass1)){
            System.out.println("Same");
        }else {
            System.out.println("Different");
        }
    }
}
