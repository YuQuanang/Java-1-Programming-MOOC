
import fi.helsinki.cs.tmc.edutestutils.MockStdio;
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Rule;
import org.junit.Test;

@Points("01-25")
public class CheckYourIndentationTest {

    @Rule
    public MockStdio io = new MockStdio();

    @Test
    public void noTests() {
        // checks that the indentations are correct
    }

}
