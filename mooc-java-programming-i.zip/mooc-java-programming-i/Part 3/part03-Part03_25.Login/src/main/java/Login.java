import java.util.Arrays;
import java.util.Scanner;

public class Login {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] user = {"alex", "emma"};
        String[] pass = {"sunshine", "haskell"};
        
        System.out.println("Enter a username: ");
        String userkey = String.valueOf(scanner.nextLine());
        
        System.out.println("Enter a password: ");
        String passkey = String.valueOf(scanner.nextLine());
        boolean login = false;
        for(int i=0;i<user.length;i++){
            if(userkey.equals(user[i]) && passkey.equals(pass[i])){
                System.out.println("You have successfully logged in!");
                login = true;
            } 
        }
        if(!login){
            System.out.println("Incorrect username or password!");
        }
        
        
    }
}
