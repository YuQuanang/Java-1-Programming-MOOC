
import java.util.Scanner;

public class AverageOfNumbers {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double total = 0;
        int count = 0;
        while(true){
            System.out.println("Give a number: ");
            int num = Integer.valueOf(scanner.nextLine());
            
            if(num!=0){
                total = total + num;
                count = count+1;
            } else{
                break;
            }
        }
        total = total/count;
        System.out.println("Average of the numbers: "+total);
        
    }
}
