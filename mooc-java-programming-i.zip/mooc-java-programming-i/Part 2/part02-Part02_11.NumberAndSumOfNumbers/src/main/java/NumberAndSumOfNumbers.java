
import java.util.Scanner;

public class NumberAndSumOfNumbers {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int count=0;
        int step =0;
        
        while(true){
            System.out.println("Give a number:");
            int num = Integer.valueOf(scanner.nextLine());
            
            if(num != 0){
                count = count+num;
                step = step + 1;
            } else{
                break;
            }
        }
        System.out.println("Number of numbers: " + step);
        System.out.println("Sum of the numbers: " + count);
        
    }
}
