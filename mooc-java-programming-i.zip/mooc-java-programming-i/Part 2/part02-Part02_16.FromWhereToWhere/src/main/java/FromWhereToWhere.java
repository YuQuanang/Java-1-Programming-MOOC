
import java.util.Scanner;

public class FromWhereToWhere {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        System.out.println("Where to? ");
        int count = Integer.valueOf(scanner.nextLine());
        System.out.println("Where from? ");
        int count1 = Integer.valueOf(scanner.nextLine());
        if(!(count<count1)){
            for(int i = count1; i<=count; i++){
                System.out.println(i);
            }
        }
        
    }
}
