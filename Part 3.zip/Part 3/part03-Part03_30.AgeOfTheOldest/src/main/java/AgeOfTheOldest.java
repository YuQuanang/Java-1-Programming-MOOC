
import java.util.Scanner;

public class AgeOfTheOldest {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int age = 0;
        while(true){
            String phrase = String.valueOf(scanner.nextLine());
            
            if(phrase.equals("")){
                break;
            }
            
            String[] profile = phrase.split(",");
            if(age<Integer.valueOf(profile[1])){
                age = Integer.valueOf(profile[1]);
            }
        }
        System.out.println("Age of the oldest: " + age);

    }
}
