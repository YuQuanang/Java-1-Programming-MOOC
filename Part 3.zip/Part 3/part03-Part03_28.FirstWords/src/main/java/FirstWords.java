
import java.util.Scanner;

public class FirstWords {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(true){
            String phrase = String.valueOf(scanner.nextLine());
            
            if(phrase.equals("")){
                break;
            }
            
            String[] word = phrase.split(" ");
            System.out.println(word[0]);
        }

    }
}
