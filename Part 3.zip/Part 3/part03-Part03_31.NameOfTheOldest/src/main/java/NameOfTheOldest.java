
import java.util.Scanner;

public class NameOfTheOldest {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int age = 0;
        String name = "";
        while(true){
            String phrase = String.valueOf(scanner.nextLine());
            
            if(phrase.equals("")){
                break;
            }
            
            String[] profile = phrase.split(",");
            if(age<Integer.valueOf(profile[1])){
                name = profile[0];
                age = Integer.valueOf(profile[1]);
            }
        }
        System.out.println("Name of the oldest: " + name);

    }
}
