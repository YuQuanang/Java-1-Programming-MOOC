
import java.util.Scanner;

public class LastWords {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while(true){
            String phrase = String.valueOf(scanner.nextLine());
            
            if(phrase.equals("")){
                break;
            }
            
            String[] word = phrase.split(" ");
            System.out.println(word[(word.length-1)]);
        }
        

    }
}
