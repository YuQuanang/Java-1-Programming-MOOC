
import java.util.ArrayList;
import java.util.Scanner;

public class PersonalDetails {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int len = 0;
        String name = "";
        double sum = 0;
        int count = 0;
        while(true){
            String phrase = String.valueOf(scanner.nextLine());
            
            if(phrase.equals("")){
                break;
            }
            
            String[] profile = phrase.split(",");
            
            // finding the longest name
            if(len<profile[0].length()){
                len = profile[0].length();
                name = profile[0];
            }
            
            // finding the average birth year
            sum += Double.valueOf(profile[1]);
            count++;
            
        }
        // calc avg
        double avg = sum/count;
        //Display
        System.out.println("Longest name: "+name);
        System.out.println("Average of the birth years: "+avg);

    }
}
