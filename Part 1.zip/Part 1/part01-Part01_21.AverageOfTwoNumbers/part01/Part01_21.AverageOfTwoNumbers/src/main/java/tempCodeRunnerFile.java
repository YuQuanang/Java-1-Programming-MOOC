isor = 2;

    double result = dividend / divisor * 1.0;
    System.out.println(result);
        }